let json = {
    'title': 'test json response',
    'message': 'this is a message',
    'time': 'now',
    'status': 200
}

module.exports = json
